package com.example.vendini

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
