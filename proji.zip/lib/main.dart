import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:vendini/pages/connexion.dart';
import 'package:vendini/pages/paiement.dart';
import 'package:vendini/pages/vendeur.dart';
import 'firebase_options.dart';
import 'package:vendini/pages/splash_screen.dart';
import 'package:vendini/pages/welcome_screen.dart';
import 'package:vendini/pages/threepage.dart';
import 'package:vendini/pages/fourpage.dart';
import 'package:vendini/pages/fivepage.dart';
import 'package:vendini/pages/sixpage.dart';
import 'package:vendini/pages/panier.dart';
import 'package:vendini/pages/post.dart';
import 'package:vendini/pages/history.dart';
import 'package:vendini/pages/infprod.dart';
import 'package:vendini/pages/favoris.dart';
import 'package:vendini/pages/profil.dart';
import 'package:vendini/pages/home.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  final FirebaseAuth _auth = FirebaseAuth.instance;
  User? user = _auth.currentUser; // Get the current user
  String userId = user?.uid ?? ''; // Get user ID or set to empty string if not logged in
  runApp(MyApp(userId: userId)); // Pass userId to MyApp
}

class MyApp extends StatelessWidget {
  final String userId;
  const MyApp({Key? key, required this.userId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vendini',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: const Color(0xFFE6B8AF),
        hintColor: const Color(0xFFA34961),
        fontFamily: 'Roboto',
        textTheme: const TextTheme(),
        buttonTheme: ButtonThemeData(
          buttonColor: const Color(0xFFA34961),
          textTheme: ButtonTextTheme.primary,
        ),
      ),
      home: userId.isNotEmpty ? HomePage(userId: userId) : const SplashScreen(),
      routes: {
        '/vendeur': (context) => const Vendeur(),
        '/infoProd': (context) => Infprod(),
        '/addProduct': (context) => const AddProductPage(),
        '/history': (context) => HistoryPage(userId: userId),
        '/cart': (context) {
          final String userId = getUserIdFromContext(context);
          return PanierPage(userId: userId);
        },
        '/infoProduit': (context) => Infprod(userId: userId),
        '/welcome': (context) => WelcomeScreen(userId: userId),
        '/three': (context) => ThreePage(userId: userId),
        '/four': (context) => FourPage(userId: userId),
        '/five': (context) => FivePage(userId: userId),
        '/six': (context) => SixPage(userId: userId),
        '/payement': (context) {
          final String userId = getUserIdFromContext(context);
          return Paiement(userId: userId);
        },
        '/login': (context) => LoginPage(),
      },
    );
  }
}

String? getUserIdFromContext(BuildContext context) {
  final user = FirebaseAuth.instance.currentUser;
  return user?.uid;
}
