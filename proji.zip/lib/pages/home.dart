import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:vendini/pages/favoris.dart'; // Import the FavorisPage
import 'package:vendini/pages/profil.dart'; // Import the ProfilPage

class HomePage extends StatefulWidget {
  final String userId; // Add userId as a parameter
  const HomePage({Key? key, required this.userId}) : super(key: key);
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  String? _userName;
  String? _userProfileImage;
  bool isLoading = true;

  final List<Map<String, String>> _scrollProducts = [
    {'name': 'Produit 1', 'price': '20 TND', 'image': 'assets/images/1.png', 'id': 'p1'},
    {'name': 'Produit 2', 'price': '40 TND', 'image': 'assets/images/2.png', 'id': 'p2'},
    {'name': 'Produit 3', 'price': '60 TND', 'image': 'assets/images/3.png', 'id': 'p3'},
    {'name': 'Produit 5', 'price': '100 TND', 'image': 'assets/images/5.png', 'id': 'p4'},
  ];

  final List<Map<String, String>> _blurProducts = [
    {'name': 'Pyjama', 'price': '30 TND', 'image': 'assets/images/4.png', 'id': 'p5'},
    {'name': 'Manteau', 'price': '50 TND', 'image': 'assets/images/5.png', 'id': 'p6'},
    {'name': 'Les misérables', 'price': '80 TND', 'image': 'assets/images/6.png', 'id': 'p7'},
    {'name': 'Armoire', 'price': '200 TND', 'image': 'assets/images/7.png', 'id': 'p8'},
  ];

  final TextEditingController _searchController = TextEditingController();
  List<Map<String, String>> _filteredProducts = [];
  final Set<Map<String, dynamic>> _favoriteProducts = Set<Map<String, dynamic>>();

  @override
  void initState() {
    super.initState();
    _filteredProducts = List.from(_blurProducts);
    _searchController.addListener(_filterProducts);
    _initUser();
  }

  @override
  void dispose() {
    _searchController.removeListener(_filterProducts);
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _initUser() async {
    User? user = _auth.currentUser;
    if (user != null) {
      try {
        DocumentSnapshot userDoc = await _firestore.collection('users').doc(user.uid).get();

        if (userDoc.exists) {
          setState(() {
            _userName = userDoc['nom'] + ' ' + userDoc['prenom'] ?? 'User';
            _userProfileImage = userDoc['profileImage'] ?? 'assets/images/default_profile.png';
            isLoading = false;
          });
        }
      } catch (e) {
        print('Error retrieving user data: $e');
      }
    }
  }

  void _filterProducts() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredProducts = _blurProducts
          .where((product) => product['name']!.toLowerCase().contains(query) || product['price']!.contains(query))
          .toList();
    });
  }

  Future<void> _addProductToCart(String productId) async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      try {
        CollectionReference cartCollection = FirebaseFirestore.instance.collection('users').doc(user.uid).collection('cart');

        await cartCollection.add({
          'productId': productId,
          'timestamp': FieldValue.serverTimestamp(),
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Produit ajouté au panier')),
        );
      } catch (e) {
        print('Error adding product to cart: $e');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur lors de l\'ajout au panier')),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Veuillez vous connecter pour ajouter des produits au panier')),
      );
    }
  }

  Widget _buildProductCard(String productName, String price, String imagePath, String productId, {bool showCartIcon = false}) {
    return GestureDetector(
      onTap: () {
        _addProductToCart(productId);
      },
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width * 0.04),
        child: Card(
          elevation: 5,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          child: Stack(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.asset(
                  imagePath,
                  width: MediaQuery.of(context).size.width * 0.4,
                  height: MediaQuery.of(context).size.height * 0.2,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                bottom: 5,
                left: 10,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      productName,
                      style: const TextStyle(
                        color: Color.fromARGB(255, 251, 251, 251),
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    Text(
                      price,
                      style: const TextStyle(
                        color: Color.fromARGB(255, 143, 131, 131),
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ),
              if (showCartIcon)
                Positioned(
                  top: 5,
                  right: 5,
                  child: GestureDetector(
                    onTap: () {
                      _addProductToCart(productId);
                    },
                    child: const CircleAvatar(
                      backgroundColor: Colors.white,
                      radius: 15,
                      child: Icon(Icons.add_shopping_cart, color: Colors.pink, size: 18),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return Scaffold(
      drawer: _buildDrawer(),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFCDFDB),
        automaticallyImplyLeading: false,
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu, color: Colors.white),
            onPressed: () {
              Scaffold.of(context).openDrawer();
            },
          ),
        ),
        title: Row(
          children: [
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ProfilPage()),
                );
              },
              child: CircleAvatar(
                radius: MediaQuery.of(context).size.width * 0.07,
                backgroundImage: _userProfileImage != null
                    ? NetworkImage(_userProfileImage!)
                    : AssetImage("assets/profile.png") as ImageProvider,
              ),
            ),
            SizedBox(width: MediaQuery.of(context).size.width * 0.01),
            Expanded(
              child: Text(
                _userName ?? "",
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: MediaQuery.of(context).size.width * 0.035,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
            IconButton(
              icon: const Icon(Icons.favorite, color: Colors.white),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const FavorisPage()),
                );
              },
            ),
            IconButton(
              icon: const Icon(Icons.shopping_cart, color: Colors.white),
              onPressed: () {
                Navigator.pushNamed(context, '/cart');
              },
            ),
            IconButton(
              icon: Image.asset('assets/images/logout.png', width: 24, height: 24),
              onPressed: () async {
                await _auth.signOut();
                Navigator.pushReplacementNamed(context, '/login');
              },
            ),
          ],
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/background.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.04),
              child: Text(
                'Découvrez nos offres !',
                style: TextStyle(
                  fontSize: MediaQuery.of(context).size.width * 0.06,
                  fontWeight: FontWeight.bold,
                  color: const Color(0xFFB50D56),
                ),
              ),
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.2,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: _scrollProducts
                      .map((product) => _buildProductCard(
                    product['name']!,
                    product['price']!,
                    product['image']!,
                    product['id']!,
                    showCartIcon: true,
                  ))
                      .toList(),
                ),
              ),
            ),
            const SizedBox(height: 16.0),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width * 0.04),
              child: TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  hintText: 'Rechercher un produit...',
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16.0),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(1.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
                    child: Container(
                      color: Colors.white.withOpacity(0.5),
                      padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.04),
                      child: GridView.builder(
                        itemCount: _filteredProducts.length,
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: MediaQuery.of(context).size.width > 600 ? 3 : 2,
                          crossAxisSpacing: MediaQuery.of(context).size.width * 0.04,
                          mainAxisSpacing: MediaQuery.of(context).size.height * 0.02,
                        ),
                        itemBuilder: (context, index) {
                          final product = _filteredProducts[index];
                          return _buildProductCard(
                            product['name']!,
                            product['price']!,
                            product['image']!,
                            product['id']!,
                            showCartIcon: true,
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomNavBar(),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.pink,
        child: const Icon(Icons.camera_alt),
        onPressed: () {
          Navigator.pushNamed(context, '/addProduct');
        },
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      child: ListView(
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
              color: const Color.fromARGB(255, 237, 188, 223),
            ),
            child: Text(
              'Catégories',
              style: TextStyle(color: Colors.white, fontSize: 24),
            ),
          ),
          ListTile(
            title: Text('Vêtement'),
            onTap: () {
              Navigator.pop(context);
              _filterByCategory('Vêtement');
            },
          ),
          ListTile(
            title: Text('Meuble'),
            onTap: () {
              Navigator.pop(context);
              _filterByCategory('Meuble');
            },
          ),
          ListTile(
            title: Text('Livres'),
            onTap: () {
              Navigator.pop(context);
              _filterByCategory('Livres');
            },
          ),
          ListTile(
            title: Text('Vaisselle'),
            onTap: () {
              Navigator.pop(context);
              _filterByCategory('Vaisselle');
            },
          ),
          ListTile(
            title: Text('Électroménager'),
            onTap: () {
              Navigator.pop(context);
              _filterByCategory('Électroménager');
            },
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavBar() {
    return BottomAppBar(
      shape: const CircularNotchedRectangle(),
      notchMargin: 10.0,
      color: const Color(0xFFFCDFDB),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
            icon: const Icon(Icons.home, color: Colors.white),
            onPressed: () {
              print('Accueil');
            },
          ),
          IconButton(
            icon: const Icon(Icons.history, color: Colors.white),
            onPressed: () {
              Navigator.pushNamed(context, '/history');
            },
          ),
          const SizedBox(width: 40),
          IconButton(
            icon: const Icon(Icons.notifications, color: Colors.white),
            onPressed: () {
              print('Notifications');
            },
          ),
        ],
      ),
    );
  }

  void _filterByCategory(String category) {
    setState(() {
      if (category == 'Vêtement') {
        _filteredProducts = _blurProducts
            .where((product) =>
        product['image'] == 'assets/images/4.png' ||
            product['image'] == 'assets/images/5.png')
            .toList();
      } else if (category == 'Meuble') {
        _filteredProducts = _blurProducts
            .where((product) => product['image'] == 'assets/images/7.png')
            .toList();
      } else if (category == 'Livres') {
        _filteredProducts = _blurProducts
            .where((product) => product['image'] == 'assets/images/6.png')
            .toList();
      } else if (category == 'Vaisselle' || category == 'Électroménager') {
        _filteredProducts = [];
      }
    });
  }
}
