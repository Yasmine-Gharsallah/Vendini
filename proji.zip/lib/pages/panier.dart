import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class PanierPage extends StatefulWidget {
  final String userId;

  const PanierPage({super.key, required this.userId});

  @override
  _PanierPageState createState() => _PanierPageState();
}

class _PanierPageState extends State<PanierPage> {
  List<Map<String, dynamic>> products = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchCartProducts();
  }

  Future<void> fetchCartProducts() async {
    try {
      final fetchedProducts = await getUserCartProducts(widget.userId);
      setState(() {
        products = fetchedProducts;
        isLoading = false;
      });
    } catch (e) {
      print('Error fetching cart products: $e');
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            height: double.infinity,
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/background.png'),
                fit: BoxFit.cover,
              ),
            ),
            child: isLoading
                ? Center(child: CircularProgressIndicator())
                : products.isEmpty
                ? Center(
              child: Text(
                'Votre panier est vide.',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black54,
                ),
              ),
            )
                : ListView.builder(
              itemCount: products.length,
              itemBuilder: (context, index) {
                final product = products[index];
                return Card(
                  margin: const EdgeInsets.all(10),
                  child: ListTile(
                    leading: Image.network(
                      product['image'],
                      fit: BoxFit.cover,
                      width: 60,
                    ),
                    title: Text(
                      product['name'],
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    subtitle: Text(
                      '${product['price']} TND',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.black54,
                      ),
                    ),
                    trailing: IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () async {
                        await removeProductFromCart(widget.userId, product['id']);
                        setState(() {
                          products.removeAt(index);
                        });
                      },
                    ),
                  ),
                );
              },
            ),
          ),
          Positioned(
            top: 30,
            left: 15,
            child: IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.white, size: 30),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ),
        ],
      ),
    );
  }

  Future<List<Map<String, dynamic>>> getUserCartProducts(String userId) async {
    try {
      final cartCollection = FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .collection('cart');

      final cartSnapshot = await cartCollection.get();
      final productIds = cartSnapshot.docs.map((doc) => doc.data()['productId'] as String).toList();

      if (productIds.isEmpty) return [];

      final productsCollection = FirebaseFirestore.instance.collection('products');
      final productsSnapshot = await productsCollection.where(FieldPath.documentId, whereIn: productIds).get();

      return productsSnapshot.docs.map((doc) {
        final data = doc.data();
        return {
          'id': doc.id,
          'name': data['name'],
          'price': data['price'],
          'image': data['image'],
        };
      }).toList();
    } catch (e) {
      print('Error fetching products: $e');
      return [];
    }
  }

  Future<void> removeProductFromCart(String userId, String productId) async {
    try {
      final cartCollection = FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .collection('cart');

      final cartSnapshot = await cartCollection.where('productId', isEqualTo: productId).get();

      for (var doc in cartSnapshot.docs) {
        await doc.reference.delete();
      }
    } catch (e) {
      print('Error removing product: $e');
    }
  }
}
